import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report

# Sample data
data = {'text': ['Win money now!!!', 'Hello, how are you?', "Congratulations, you've won a prize!", 'Please find the report attached', 'This is not spam, just a friendly reminder', 'You are selected for a free gift card', 'Get rich quick with this simple trick', 'Meeting at 3 PM today', 'Can we reschedule our call?', 'Earn money working from home'], 'label': [1, 0, 1, 0, 0, 1, 1, 0, 0, 1]}
df = pd.DataFrame(data)

# Split data
X_train, X_test, y_train, y_test = train_test_split(df['text'], df['label'], test_size=0.3, random_state=42)

# Vectorize text
vectorizer = CountVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Train model
model = MultinomialNB()
model.fit(X_train_vec, y_train)

# Evaluate
y_pred = model.predict(X_test_vec)
print(classification_report(y_test, y_pred))
