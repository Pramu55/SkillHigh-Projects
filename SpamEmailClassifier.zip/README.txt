Spam Email Classifier
===========================
Objective:
    Build a simple spam detection model using machine learning.

Technologies Used:
    - Python
    - Scikit-learn
    - Pandas

Steps:
    1. Load and label sample email texts.
    2. Preprocess text using CountVectorizer.
    3. Train Naive Bayes classifier.
    4. Evaluate and save classification report.

Real-World Application:
    Used in email services to automatically filter spam messages.
