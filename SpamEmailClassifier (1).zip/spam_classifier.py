import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report

# Expanded dataset
data = {'text': ['Win a brand new car by entering the contest now!', "Meeting agenda for tomorrow's team sync.", 'Claim your free vacation package today. Limited offer!', 'Reminder: Your invoice is due by the end of the week.', "You've been selected for a cash reward. Click here to claim.", 'Weekly report attached. Let me know if any questions.', 'Urgent! Your account has been compromised. Reset your password immediately.', "Let's catch up over coffee this weekend.", 'Special promotion: Buy one, get one free on all items!', 'Your subscription is expiring soon. Renew now.', 'Check out our new product launch event this Friday.', 'You have a pending tax refund. Provide your details to receive it.', "Hope you're doing well. Just checking in!", 'Earn $1000 per day working from home. Sign up now!', 'Schedule confirmed for your upcoming interview.', "Exclusive deal for premium members only. Don't miss out!", "Minutes from today's meeting are attached.", 'Win big in the lottery. No purchase necessary!', 'Follow up on the client proposal we discussed.', "Congratulations! You're a lucky winner!", 'New company policy update. Please review carefully.', 'Instant loan approval, no credit check required.', 'Team lunch is planned for Thursday afternoon.', 'Click to get a discount code for your next order.', 'Can you send over the presentation slides?'], 'label': [1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0]}
df = pd.DataFrame(data)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    df['text'], df['label'], test_size=0.3, random_state=42)

# Vectorization with stop words removed
vectorizer = CountVectorizer(stop_words='english')
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Naive Bayes Classifier
model = MultinomialNB()
model.fit(X_train_vec, y_train)

# Prediction and Evaluation
y_pred = model.predict(X_test_vec)
print(classification_report(y_test, y_pred))
