import streamlit as st
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir, 'src'))
from predict import SpamClassifier

st.set_page_config(page_title='Spam Email Classifier', page_icon='📧', layout='centered')

st.title('📧 Spam Email Classifier')
st.markdown('Enter email content below and click **Classify**.')

classifier = SpamClassifier()

user_input = st.text_area('Email text', height=200)

if st.button('Classify'):
    if user_input.strip():
        result = classifier.predict(user_input)
        if result == 'Spam':
            st.error('🚨 This email looks like **SPAM**!')
        else:
            st.success('✅ This email appears **Not Spam**.')
    else:
        st.warning('Please enter some text.')
