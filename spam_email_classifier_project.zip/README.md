# Spam Email Classifier 📧

**Project Type**: Major / Final-Year Project  
**Tech Stack**: Python, Scikit‑learn, Streamlit  
**Author**: Pramod S S  

## Overview
This project delivers an end‑to‑end machine‑learning pipeline to classify emails as **Spam** or **Not Spam**.  
It covers data preprocessing, feature engineering with TF‑IDF, model training (Logistic Regression), evaluation, and an interactive Streamlit web app.

## Project Structure
```
spam_email_classifier_project/
├── data/
│   └── emails.csv         <- Sample dataset
├── src/
│   ├── data_preprocessing.py
│   ├── train_model.py
│   └── predict.py
├── app/
│   ├── app.py             <- Streamlit UI
│   ├── model.pkl          <- Saved model (auto‑generated)
│   └── vectorizer.pkl     <- Saved TF‑IDF vectorizer
├── reports/
│   └── classification_report.txt
├── requirements.txt
└── README.md
```

## Quick Start

1. **Create & activate** a virtual environment  
   ```bash
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   ```

2. **Install dependencies**  
   ```bash
   pip install -r requirements.txt
   ```

3. **(Re)Train the model**  
   ```bash
   cd src
   python train_model.py
   ```

4. **Launch the web app**  
   ```bash
   streamlit run app/app.py
   ```

## Dataset
A tiny illustrative dataset (`data/emails.csv`) is bundled for quick experimentation.  
Replace it with a larger corpus (e.g., [SMS Spam Collection] or [Enron Email Dataset]) to achieve production‑grade accuracy.

## Model
* **Preprocessing**: custom stop‑word removal, punctuation cleaning  
* **Vectorization**: TF‑IDF (scikit‑learn)  
* **Classifier**: Logistic Regression  

## Evaluation
Training produces `reports/classification_report.txt` and prints Accuracy/F1 scores in the console.

## UI
The Streamlit interface (`app/app.py`) provides:
* Rich text box for pasting email content
* One‑click “Classify” button
* Color‑coded prediction result (✅ Not Spam / 🚨 Spam)

## Screenshots
![UI Screenshot](https://dummyimage.com/800x450/121212/ffffff&text=Spam+Email+Classifier+Demo)

---

> **Tip**: To integrate with Gmail or Outlook, wrap `predict.SpamClassifier` in an API endpoint or scheduled script.
