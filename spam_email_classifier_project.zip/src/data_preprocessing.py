import re
import string
from sklearn.base import BaseEstimator, TransformerMixin

class TextPreprocessor(BaseEstimator, TransformerMixin):
    """Simple text cleaner + stop‑word remover."""

    def __init__(self, stopwords=None):
        default_stopwords = {
            'the','and','is','in','to','for','of','on','at','a','an','be','this','that',
            'with','as','it','your','you','from','by','are','has','have','will','can'
        }
        self.stopwords = set(stopwords) if stopwords else default_stopwords

    def clean_text(self, text: str) -> str:
        text = text.lower()
        text = re.sub(r"http\S+", "", text)                    # remove URLs
        text = text.translate(str.maketrans('', '', string.punctuation))
        words = text.split()
        words = [w for w in words if w not in self.stopwords]
        return ' '.join(words)

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [self.clean_text(t) for t in X]
