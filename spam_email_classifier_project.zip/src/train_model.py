import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score

from data_preprocessing import TextPreprocessor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
DATA_PATH = os.path.join(ROOT, 'data', 'emails.csv')
MODEL_PATH = os.path.join(ROOT, 'app', 'model.pkl')
VECTORIZER_PATH = os.path.join(ROOT, 'app', 'vectorizer.pkl')
REPORT_PATH = os.path.join(ROOT, 'reports', 'classification_report.txt')

def main():
    df = pd.read_csv(DATA_PATH)
    X, y = df['text'], df['label']

    pre = TextPreprocessor()
    X_clean = pre.transform(X)

    vectorizer = TfidfVectorizer()
    X_vec = vectorizer.fit_transform(X_clean)

    X_train, X_test, y_train, y_test = train_test_split(X_vec, y, test_size=0.2, random_state=42)

    clf = LogisticRegression(max_iter=1000)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)

    # Persist artifacts
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(clf, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)

    # Save report
    os.makedirs(os.path.dirname(REPORT_PATH), exist_ok=True)
    with open(REPORT_PATH, 'w') as f:
        f.write(f'Accuracy: {acc:.4f}\n\n')
        f.write(report)

    print(f'✓ Model saved to {{MODEL_PATH}}')
    print(f'✓ Vectorizer saved to {{VECTORIZER_PATH}}')
    print(f'Accuracy: {{acc:.4f}}')
    print(report)

if __name__ == '__main__':
    main()
