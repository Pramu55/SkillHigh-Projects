import os
import joblib
from data_preprocessing import TextPreprocessor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
MODEL_PATH = os.path.join(ROOT, 'app', 'model.pkl')
VECTORIZER_PATH = os.path.join(ROOT, 'app', 'vectorizer.pkl')

class SpamClassifier:
    def __init__(self):
        self.pre = TextPreprocessor()
        self.model = joblib.load(MODEL_PATH)
        self.vectorizer = joblib.load(VECTORIZER_PATH)

    def predict(self, text: str) -> str:
        clean_text = self.pre.transform([text])
        X_vec = self.vectorizer.transform(clean_text)
        pred = self.model.predict(X_vec)[0]
        return 'Spam' if pred == 1 else 'Not Spam'

if __name__ == "__main__":
    clf = SpamClassifier()
    sample = input("Enter text to classify: ")
    print(clf.predict(sample))
